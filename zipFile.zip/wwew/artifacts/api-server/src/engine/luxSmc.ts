// ─── LuxSMC Engine ────────────────────────────────────────────────────────────
// Rebuilt from Smart Money Concepts logic:
// FVG, BOS, CHoCH, Order Blocks, Equal Highs/Lows, Premium/Discount zones

export interface Candle {
  time:  number;
  open:  number;
  high:  number;
  low:   number;
  close: number;
}

export type LuxEventType =
  | "FVG_BULLISH"
  | "FVG_BEARISH"
  | "BOS_BULLISH"
  | "BOS_BEARISH"
  | "CHOCH_BULLISH"
  | "CHOCH_BEARISH"
  | "OB_BULLISH"
  | "OB_BEARISH"
  | "EQH"
  | "EQL";

export interface LuxEvent {
  type:    LuxEventType;
  price?:  number;
  top?:    number;
  bottom?: number;
  time:    number;
  label:   string;
}

export interface OrderBlock {
  type:   "BULLISH" | "BEARISH";
  top:    number;
  bottom: number;
  time:   number;
  broken: boolean;
}

export interface EqualLevel {
  type:  "EQH" | "EQL";
  price: number;
  time:  number;
}

export interface PremiumDiscount {
  zone:      "PREMIUM" | "DISCOUNT" | "EQUILIBRIUM";
  mid:       number;
  rangeHigh: number;
  rangeLow:  number;
}

export interface LuxSmcResult {
  events:          LuxEvent[];
  orderBlocks:     OrderBlock[];
  equalLevels:     EqualLevel[];
  premiumDiscount: PremiumDiscount;
  fvgZones:        Array<{ type: "BULLISH" | "BEARISH"; top: number; bottom: number; time: number }>;
}

// ─── Fair Value Gaps ───────────────────────────────────────────────────────────

function detectFVG(candles: Candle[]): LuxSmcResult["fvgZones"] {
  const zones: LuxSmcResult["fvgZones"] = [];
  for (let i = 2; i < candles.length; i++) {
    const c1 = candles[i - 2];
    const c2 = candles[i - 1];
    const c3 = candles[i];
    if (c1.high < c3.low)  zones.push({ type: "BULLISH", top: c3.low,  bottom: c1.high, time: c2.time });
    if (c1.low  > c3.high) zones.push({ type: "BEARISH", top: c1.low,  bottom: c3.high, time: c2.time });
  }
  return zones.slice(-8);
}

// ─── Swing Detection ──────────────────────────────────────────────────────────

function findSwingHighs(candles: Candle[], lookback = 2): number[] {
  const indices: number[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    let isHigh = true;
    for (let j = 1; j <= lookback; j++) {
      if (candles[i].high <= candles[i - j].high || candles[i].high <= candles[i + j].high) {
        isHigh = false;
        break;
      }
    }
    if (isHigh) indices.push(i);
  }
  return indices;
}

function findSwingLows(candles: Candle[], lookback = 2): number[] {
  const indices: number[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    let isLow = true;
    for (let j = 1; j <= lookback; j++) {
      if (candles[i].low >= candles[i - j].low || candles[i].low >= candles[i + j].low) {
        isLow = false;
        break;
      }
    }
    if (isLow) indices.push(i);
  }
  return indices;
}

// ─── BOS / CHoCH ──────────────────────────────────────────────────────────────

function detectBosChoch(candles: Candle[]): LuxEvent[] {
  const events: LuxEvent[] = [];
  const highIdx = findSwingHighs(candles);
  const lowIdx  = findSwingLows(candles);

  // BOS Bullish: current candle closes above previous swing high
  if (highIdx.length >= 1) {
    const lastHigh = highIdx[highIdx.length - 1];
    const last = candles[candles.length - 1];
    if (last.close > candles[lastHigh].high && candles.length - 1 > lastHigh) {
      events.push({
        type:  "BOS_BULLISH",
        price: candles[lastHigh].high,
        time:  last.time,
        label: "📈 Bullish BOS (structure break)",
      });
    }
  }

  // BOS Bearish: current candle closes below previous swing low
  if (lowIdx.length >= 1) {
    const lastLow = lowIdx[lowIdx.length - 1];
    const last = candles[candles.length - 1];
    if (last.close < candles[lastLow].low && candles.length - 1 > lastLow) {
      events.push({
        type:  "BOS_BEARISH",
        price: candles[lastLow].low,
        time:  last.time,
        label: "📉 Bearish BOS (structure break)",
      });
    }
  }

  // CHoCH Bullish: lower high reversed — new high breaks previous lower high
  if (highIdx.length >= 2) {
    const h1 = highIdx[highIdx.length - 2];
    const h2 = highIdx[highIdx.length - 1];
    if (candles[h2].high < candles[h1].high) {
      const last = candles[candles.length - 1];
      if (last.close > candles[h1].high) {
        events.push({
          type:  "CHOCH_BULLISH",
          price: candles[h1].high,
          time:  last.time,
          label: "🔄 Bullish CHoCH (character change)",
        });
      }
    }
  }

  // CHoCH Bearish: higher low reversed — new low breaks previous higher low
  if (lowIdx.length >= 2) {
    const l1 = lowIdx[lowIdx.length - 2];
    const l2 = lowIdx[lowIdx.length - 1];
    if (candles[l2].low > candles[l1].low) {
      const last = candles[candles.length - 1];
      if (last.close < candles[l1].low) {
        events.push({
          type:  "CHOCH_BEARISH",
          price: candles[l1].low,
          time:  last.time,
          label: "🔄 Bearish CHoCH (character change)",
        });
      }
    }
  }

  return events;
}

// ─── Order Blocks ─────────────────────────────────────────────────────────────
// Bullish OB = last bearish candle before a bullish BOS move
// Bearish OB = last bullish candle before a bearish BOS move

function detectOrderBlocks(candles: Candle[]): OrderBlock[] {
  const blocks: OrderBlock[] = [];
  const currentPrice = candles[candles.length - 1].close;

  for (let i = 5; i < candles.length - 3; i++) {
    const pivot = candles[i];
    // Bullish move after this candle?
    const future = candles.slice(i + 1, i + 6);
    const maxFutureClose = Math.max(...future.map(c => c.close));

    // Bullish OB: current candle is bearish, strong bullish move follows
    if (pivot.close < pivot.open) {
      const moveUp = (maxFutureClose - pivot.close) / pivot.close;
      if (moveUp > 0.004) {
        blocks.push({
          type:   "BULLISH",
          top:    pivot.open,
          bottom: pivot.close,
          time:   pivot.time,
          broken: currentPrice < pivot.close,
        });
      }
    }

    // Bearish OB: current candle is bullish, strong bearish move follows
    if (pivot.close > pivot.open) {
      const minFutureClose = Math.min(...future.map(c => c.close));
      const moveDown = (pivot.close - minFutureClose) / pivot.close;
      if (moveDown > 0.004) {
        blocks.push({
          type:   "BEARISH",
          top:    pivot.close,
          bottom: pivot.open,
          time:   pivot.time,
          broken: currentPrice > pivot.close,
        });
      }
    }
  }

  // Keep only last 3 unbroken blocks of each type
  const bullish = blocks.filter(b => b.type === "BULLISH" && !b.broken).slice(-3);
  const bearish = blocks.filter(b => b.type === "BEARISH" && !b.broken).slice(-3);
  return [...bullish, ...bearish];
}

// ─── Equal Highs / Lows ───────────────────────────────────────────────────────

function detectEqualLevels(candles: Candle[], threshold = 0.001): EqualLevel[] {
  const levels: EqualLevel[] = [];
  const highIdx = findSwingHighs(candles);
  const lowIdx  = findSwingLows(candles);

  for (let i = 1; i < highIdx.length; i++) {
    const h1 = candles[highIdx[i - 1]];
    const h2 = candles[highIdx[i]];
    if (Math.abs(h1.high - h2.high) / h1.high < threshold) {
      levels.push({ type: "EQH", price: (h1.high + h2.high) / 2, time: h2.time });
    }
  }

  for (let i = 1; i < lowIdx.length; i++) {
    const l1 = candles[lowIdx[i - 1]];
    const l2 = candles[lowIdx[i]];
    if (Math.abs(l1.low - l2.low) / l1.low < threshold) {
      levels.push({ type: "EQL", price: (l1.low + l2.low) / 2, time: l2.time });
    }
  }

  return levels.slice(-6);
}

// ─── Premium / Discount ───────────────────────────────────────────────────────

function detectPremiumDiscount(candles: Candle[]): PremiumDiscount {
  const lookback = Math.min(50, candles.length);
  const slice = candles.slice(-lookback);
  const rangeHigh = Math.max(...slice.map(c => c.high));
  const rangeLow  = Math.min(...slice.map(c => c.low));
  const mid       = (rangeHigh + rangeLow) / 2;
  const price     = candles[candles.length - 1].close;

  let zone: PremiumDiscount["zone"] = "EQUILIBRIUM";
  if (price > mid * 1.003)  zone = "PREMIUM";
  if (price < mid * 0.997)  zone = "DISCOUNT";

  return { zone, mid, rangeHigh, rangeLow };
}

// ─── Main Export ──────────────────────────────────────────────────────────────

export function detectLuxSMC(candles: Candle[]): LuxSmcResult {
  if (candles.length < 10) {
    return {
      events:          [],
      orderBlocks:     [],
      equalLevels:     [],
      fvgZones:        [],
      premiumDiscount: { zone: "EQUILIBRIUM", mid: 0, rangeHigh: 0, rangeLow: 0 },
    };
  }

  const fvgZones     = detectFVG(candles);
  const bosChoch     = detectBosChoch(candles);
  const orderBlocks  = detectOrderBlocks(candles);
  const equalLevels  = detectEqualLevels(candles);
  const pd           = detectPremiumDiscount(candles);

  const events: LuxEvent[] = [...bosChoch];

  // FVG events (last 2 only to avoid spam)
  for (const fvg of fvgZones.slice(-2)) {
    events.push({
      type:   fvg.type === "BULLISH" ? "FVG_BULLISH" : "FVG_BEARISH",
      top:    fvg.top,
      bottom: fvg.bottom,
      time:   fvg.time,
      label:  fvg.type === "BULLISH" ? "🟢 Bullish FVG formed" : "🔴 Bearish FVG formed",
    });
  }

  // OB events
  for (const ob of orderBlocks.slice(-2)) {
    events.push({
      type:   ob.type === "BULLISH" ? "OB_BULLISH" : "OB_BEARISH",
      top:    ob.top,
      bottom: ob.bottom,
      time:   ob.time,
      label:  ob.type === "BULLISH" ? "🟦 Bullish Order Block" : "🟥 Bearish Order Block",
    });
  }

  // EQH/EQL events
  for (const eq of equalLevels.slice(-2)) {
    events.push({
      type:  eq.type,
      price: eq.price,
      time:  eq.time,
      label: eq.type === "EQH" ? "🎯 Equal Highs (liquidity above)" : "🎯 Equal Lows (liquidity below)",
    });
  }

  return { events, orderBlocks, equalLevels, fvgZones, premiumDiscount: pd };
}

// ─── Telegram Message Builder ─────────────────────────────────────────────────

export function buildMarketIntelligenceMessage(
  symbol:  string,
  price:   number,
  result:  LuxSmcResult,
): string {
  const { events, premiumDiscount } = result;
  if (!events.length) return "";

  const pd = premiumDiscount;
  const pdLine =
    pd.zone === "PREMIUM"
      ? "📍 Price in PREMIUM zone (potential sell area)"
      : pd.zone === "DISCOUNT"
      ? "📍 Price in DISCOUNT zone (potential buy area)"
      : "📍 Price at EQUILIBRIUM (mid-range)";

  const lines = events.map(e => e.label);

  return (
    `📊 <b>${symbol}</b>  $${price.toFixed(2)}\n\n` +
    lines.join("\n") +
    `\n\n${pdLine}`
  );
}
